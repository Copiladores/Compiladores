﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalizadorLexico.Lexico
{
    using System.Windows.Forms;
    /// <summary>
    /// Defines the <see cref="Lexe" />
    /// </summary>
    
        public class Lexer
        {
            #region Fields
            /// <summary>
            /// Definir variable privada _Cadena
            /// </summary>
            internal string _Cadena;
            // Variables para el proceso de la cadena
            /// <summary>
            /// Definir la variable de posicion
            /// </summary>
            internal int posicion = 0;
            /// <summary>
            /// Definir variable temporal para el tamaño de la cadena temp
            /// </summary>
            internal int temp;
            #endregion
            #region Constructors
            /// <summary>
            /// Initializes a new instance of the <see cref="Lex"/> class.
            /// </summary>
            /// <param name="cadena">The <see cref="string"/></param>
            /// 
            public Lexer(string cadena)
            {
            temp = cadena.Length - 1;
            Cadena = cadena;

        }
        #endregion
        #region Properties
        /// <summary>
        /// Gets or sets the Cadena
        /// </summary>        internal string Cadena
        {
            get { return _Cadena; }
            set { _Cadena = value; }
        }
        #endregion
        #region Methods
        /// <summary>
        /// The Estado_0
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_0()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'P':
                    return Estado_30();
                    break;
                case 'L':
                    return Estado_39();
                    break;
                case 'S':
                    return Estado_43();
                    break;
                default:
                    return 0;
            }
        }
        /// <summary>
        /// The Estado_0
        /// </summary>
        /// <param name="Simbolo">The <see cref="char"/></param>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_0(char Simbolo)
        {
            char simbolo = Simbolo;
            switch (simbolo)
            {
                case 'P':
                    return Estado_30();
                    break;
                case 'L':
                    return Estado_39();
                    break;
                case 'S':
                    return Estado_43();
                    break;
                
                default:
                    return 0;
            }
        }
        /// <summary>
        /// The Estado_3
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_37()
        {
            char simbolo = Leer();
            // Estado de aceptación
            return Estado_38(simbolo);
        }
        /// <summary>
        /// The Estado_4
        /// </summary>
        /// <param name="Simbolo">The <see cref="char"/></param>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_38(char Simbolo)
        {
            if (Simbolo == ' ' || Simbolo == '\n')
            {
                MessageBox.Show("Token");
                return Estado_0();
            }
            else
            {
                MessageBox.Show("Token");
                return Estado_0(Simbolo);
            }
        }
        internal int Estado_42()
        {
            char simbolo = Leer();
            // Estado de aceptación
            return Estado_43(simbolo);
        }
        /// <summary>
        /// The Estado_4
        /// </summary>
        /// <param name="Simbolo">The <see cref="char"/></param>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_43(char Simbolo)
        {
            if (Simbolo == ' ' || Simbolo == '\n')
            {
                MessageBox.Show("Token");
                return Estado_0();
            }
            else
            {
                MessageBox.Show("Token");
                return Estado_0(Simbolo);
            }
        }

        internal int Estado_44()
        {
            char simbolo = Leer();
            // Estado de aceptación
            return Estado_45(simbolo);
        }
        /// <summary>
        /// The Estado_4
        /// </summary>
        /// <param name="Simbolo">The <see cref="char"/></param>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_45(char Simbolo)
        {
            if (Simbolo == ' ' || Simbolo == '\n')
            {
                MessageBox.Show("Token");
                return Estado_0();
            }
            else
            {
                MessageBox.Show("Token");
                return Estado_0(Simbolo);
            }
        }
        internal int Estado_48()
        {
            char simbolo = Leer();
            // Estado de aceptación
            return Estado_49(simbolo);
        }
        /// <summary>
        /// The Estado_4
        /// </summary>
        /// <param name="Simbolo">The <see cref="char"/></param>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_49(char Simbolo)
        {
            if (Simbolo == ' ' || Simbolo == '\n')
            {
                MessageBox.Show("Token");
                return Estado_0();
            }
            else
            {
                MessageBox.Show("Token");
                return Estado_0(Simbolo);
            }
        }
            /// <summary>
        /// The Estado_5
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        internal int Estado_5()
        {
            // Seguir la secuencia anterior.
            return 0;
        }
        /// <summary>
        /// The Estado_1
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        private int Estado_30()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'r':
                    return Estado_31();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        /// <summary>
        /// The Estado_2
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        private int Estado_31()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'o':
                    return Estado_32();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_32()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'g':
                    return Estado_33();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_33()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'r':
                    return Estado_34();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_34()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'a':
                    return Estado_35();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_35()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'm':
                    return Estado_36();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_36()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'a':
                    return Estado_37();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_39()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'e':
                    return Estado_40();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_40()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'e':
                    return Estado_41();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_41()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'r':
                    return Estado_42();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_43()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'i':
                    return Estado_44();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_46()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'n':
                    return Estado_47();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_47()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'o':
                    return Estado_48();
                    break;
                default:
                    return 0;
                    break;
            }
        }
        private int Estado_4()
        {
            char simbolo = Leer();
            switch (simbolo)
            {
                case 'o':
                    return Estado_48();
                    break;
                default:
                    return 0;
                    break;
            }
        }
                  
        /// <summary>
        /// Lee y procesa la cadena de entrada
        /// </summary>
        /// <returns></returns>
        private char Leer()
        {
            char Caracter;
            if (posicion <= temp)
            {
                Caracter = char.Parse(_Cadena.Substring(posicion, 1));
                posicion += 1;
                return Caracter;
            }
            else
            {
                return '\n';
            }
        }
        #endregion
    }
}


